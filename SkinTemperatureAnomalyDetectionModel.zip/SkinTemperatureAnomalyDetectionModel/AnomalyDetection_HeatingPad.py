# -*- coding: utf-8 -*-
"""
Created on Wed Apr 14 02:28:49 2021

@author: JJ
"""

from scipy import signal

from pandas import read_csv
from scipy.optimize import leastsq


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.dates as mdates


def low_pass_filter(data, cutoff, fs, n_taps=255):
    
    if data.shape[0] < n_taps * 3:
        raise ValueError(
            'Length of data should be three times longer than n_taps.')

    fil = signal.firwin(n_taps, cutoff, pass_zero=True, nyq=fs//2)
    modified_data = signal.filtfilt(fil, 1, data, axis=0)
    return modified_data 

def test_func(x, a, b,c):
    return a * np.sin(b * x)+c


SMALL_SIZE = 10
MEDIUM_SIZE = 15
BIGGER_SIZE = 15


#
##
###
# Import preparsed skin temperature measurement data with anomaly (when a heating pad is applied)
dataset = read_csv('C:/UF/TridentWearableDevice/AnomalyData/3-Day_Data.csv')

dataset['Date'] = pd.to_datetime(dataset['Date'],format='%Y%m%d_%H%M%S%f')
dataset = dataset.drop_duplicates(subset=['Date'], keep="first")
dataset=dataset.set_index('Date').resample('4S').bfill()
dataset.reset_index(inplace=True)

data_array = np.array(dataset['Skin Temp2'])
date_array = np.array(dataset['Date'])


# Low-pass filter skin temperature data with anomaly
cutoff = 1/3600
fs = 5

skin_filtered = low_pass_filter(data_array, cutoff, fs, n_taps=512)





df1 = pd.DataFrame({'skin':skin_filtered})


df2 = pd.DataFrame({'Date':date_array})

anomaly = pd.concat([df2.Date, df1.skin], axis=1)


dataset=dataset.set_index('Date')

#print(dataset.head())


## Import the resampled and fitted temperature data (normal data)
dataset1 = read_csv('FittedResampled.csv')

dataset1['Date'] = pd. to_datetime(dataset1['Date'])
dataset1=dataset1.set_index('Date')




# Find anomaly data indices in normal data other than the day and time used for template generation  
time_normal = dataset1.index.time
time_anomaly = dataset.index.time

dataset1.reset_index(inplace=True)

df1 = dataset1
df2 = pd.DataFrame({'Time':time_normal})

dataset_normal = pd.concat([df2.Time, df1], axis=1)

dataset_normal= dataset_normal.set_index('Time')



df11 = anomaly
df12 = pd.DataFrame({'Time':time_anomaly})
dataset_anomaly = pd.concat([df12.Time, df11], axis=1)
dataset_anomaly = dataset_anomaly.loc[21600*2:21600*3-1]
dataset_anomaly= dataset_anomaly.set_index('Time')
ind_list = dataset_anomaly.index.values


# Find normal data with the same anomaly data time index
dataset_normal = dataset_normal.loc[ind_list]

dataset_normal = dataset_normal[~dataset_normal.index.duplicated(keep='first')]


dataset_normal_array = np.array(dataset_normal['Fitted'])
dataset_anomaly_array = np.array(dataset_anomaly['skin'])


# Find difference between normal and anomalous temperature measurement data for matching with anomaly template
diff = dataset_anomaly_array - dataset_normal_array
diff = low_pass_filter(diff, cutoff, fs, n_taps=512)

# Normalized the difference 
diff_scaled = (diff-np.min(diff))/(np.max(diff)-np.min(diff))

# Import predifined normalized anomaly template
datasettemplate = read_csv('Template_scaled.csv')




kernel_array = np.array(datasettemplate['Skin'])
#kernel_array = kernel_array[0:4000]
date_array0 = np.array(pd.to_datetime(datasettemplate['a']))
#kernel_array = kernel_array[0:18667]
#print(kernel_array.shape)
#print(diff_scaled.shape)



#Apply match filtering on the testing difference data using fft convolution
report = np.convolve(diff_scaled,kernel_array, 'same')
dataset_anomaly.reset_index(inplace=True)
indexStart=dataset_anomaly[dataset_anomaly['Date']=='2021-04-05 16:35:00'].index.values
indexEnd=dataset_anomaly[dataset_anomaly['Date']=='2021-04-05 19:45:00'].index.values
date_array = np.array(dataset_anomaly['Date'])

date_arrayhp=date_array[indexStart[0]:indexEnd[0]+1]

#print('date_arrayhp:', date_arrayhp)
reporthp = report[indexStart[0]:indexEnd[0]+1]
c=0
threshold = 1650*np.ones((dataset_anomaly.shape[0],1))+c


#print(report.shape)

# Plot skin temperature measurement data  with anomaly, sine-wave fitted  baseline temperature data and true anomaly patter in one figure
fig, ax = plt.subplots()


ax.plot(pd.to_datetime(dataset_anomaly['Date']),dataset_anomaly_array,'o',markersize=3,markerfacecolor='black',
         markeredgecolor='black',
         markeredgewidth=1, label = 'Anomaly skin temperature')
ax.plot(pd.to_datetime(dataset_anomaly['Date']),dataset_normal_array,'o',markersize=3,markerfacecolor='blue',
         markeredgecolor='blue',
         markeredgewidth=1, label = 'Sine-fit baseline skin temperature')
ax.plot(date_arrayhp,dataset_anomaly_array[indexStart[0]:indexEnd[0]+1],'o',markersize=3,markerfacecolor='red',
         markeredgecolor='red',
         markeredgewidth=1, label = 'True anomaly')

leg = ax.legend(markerscale=3,  bbox_to_anchor=(1, 1.4),framealpha=0.0,fontsize=MEDIUM_SIZE);
ax.set_xlabel("Time (hr)",fontsize=BIGGER_SIZE,fontweight = 'bold')
ax.set_ylabel("Temperature ($^\circ$C)",fontsize=BIGGER_SIZE,fontweight = 'bold')
#ax.set_title("Anomaly Temp and Baseline Temp ",fontsize=SMALL_SIZE)
ax.tick_params(axis='x')
ax.xaxis.set_major_formatter(mdates.DateFormatter("%#H"))
ax.xaxis.set_minor_formatter(mdates.DateFormatter("%#H"))

plt.rc('font', size=MEDIUM_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=BIGGER_SIZE)
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"

right_side = ax. spines["right"]
top_side = ax. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax.spines[axis].set_linewidth(3)
    
plt.savefig('ResultPlot/Anomaly/Anomaly.pdf', bbox_inches='tight')




# Plot the differencebetween the temperature data with anomaly and sine-fitted baseline temperature data
fig, ax = plt.subplots()
ax.plot(pd.to_datetime(dataset_anomaly['Date']),diff_scaled,'o',markersize=3,markerfacecolor='black',
         markeredgecolor='black',
         markeredgewidth=1)

leg = ax.legend(framealpha=0.0);
ax.set_xlabel("Time (hr)",fontsize=BIGGER_SIZE,fontweight = 'bold')
ax.set_ylabel("Normalized Temperature",fontsize=BIGGER_SIZE,fontweight = 'bold')
#ax.set_title("Normalized Anomaly Temp - Baseline Temp",fontsize=SMALL_SIZE)
ax.tick_params(axis='x')
ax.xaxis.set_major_formatter(mdates.DateFormatter("%#H"))
ax.xaxis.set_minor_formatter(mdates.DateFormatter("%#H"))

plt.rc('font', size=MEDIUM_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=BIGGER_SIZE)
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"

right_side = ax. spines["right"]
top_side = ax. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax.spines[axis].set_linewidth(3)
    
plt.savefig('ResultPlot/Anomaly/Residue.pdf', bbox_inches='tight')

#date_array0 = date_array[0:4000]

x =np.linspace(0, 3370,3370)
# Plot the anomaly template pattern (also convolution kernel)
fig, ax = plt.subplots()
ax.plot(x,kernel_array,'o',markersize=3,markerfacecolor='black',
         markeredgecolor='black',
         markeredgewidth=1)
ax.tick_params(axis='x')

ax.set_xticks([0, 900, 1800, 2700])
ax.set_xticklabels([0, 1, 2, 3 ])
leg = ax.legend(framealpha=0.0);
ax.set_xlabel("Time (hr)",fontsize=BIGGER_SIZE,fontweight = 'bold')
ax.set_ylabel("Normalized Temperature",fontsize=BIGGER_SIZE,fontweight = 'bold')



plt.rc('font', size=MEDIUM_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=BIGGER_SIZE)
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"

right_side = ax. spines["right"]
top_side = ax. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax.spines[axis].set_linewidth(3)
    
#plt.savefig('ResultPlot/Anomaly/Anomaly Template.jpg', bbox_inches='tight')


# Plot the final convolution results, the true anomaly region and a threshold set for anomaly detection
fig, ax = plt.subplots()
ax.plot(pd.to_datetime(dataset_anomaly['Date']),report,'o',markersize=3,markerfacecolor='black',
         markeredgecolor='black',
         markeredgewidth=1, label='Convolution')
ax.plot(date_arrayhp,reporthp,'o',markersize=3,markerfacecolor='red',
         markeredgecolor='red',
         markeredgewidth=1,label='True anomaly')
ax.plot(pd.to_datetime(dataset_anomaly['Date']),threshold,'o',markersize=3,markerfacecolor='blue',
         markeredgecolor='blue',
         markeredgewidth=1, label='Threshold')
leg = ax.legend(markerscale=3, bbox_to_anchor=(0.247, 1),framealpha=0.0,fontsize=MEDIUM_SIZE);
ax.tick_params(axis='x')

ax.set_xlabel("Time (hr)",fontsize=BIGGER_SIZE,fontweight = 'bold')
ax.set_ylabel("Correlation",fontsize=BIGGER_SIZE,fontweight = 'bold')
#ax.set_title("Convolution",fontsize=SMALL_SIZE)
ax.xaxis.set_major_formatter(mdates.DateFormatter("%#H"))
ax.xaxis.set_minor_formatter(mdates.DateFormatter("%#H"))

plt.rc('font', size=MEDIUM_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=BIGGER_SIZE)
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"

right_side = ax. spines["right"]
top_side = ax. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax.spines[axis].set_linewidth(3)
    
plt.savefig('ResultPlot/Anomaly/Convolution.pdf', bbox_inches='tight')



# Define the true label arrays and predicted label arrays with '1' as anomaly and '0' as normal 

labelT=np.ones((dataset_anomaly_array.shape[0],1))
labelP=np.ones((dataset_anomaly_array.shape[0],1))
#True labels
for j in range(dataset_anomaly_array.shape[0]):
    if j >= indexStart[0] and j <= indexEnd[0]:
        labelT[j]=1
    else:
        labelT[j]=0
        
#Predicted Labels
for k in range(dataset_anomaly_array.shape[0]):
    if report[k] > 1650:
        labelP[k]=1
    else:
        labelP[k]=0        



a = np.ma.masked_where( labelT == 0, labelT)
b = np.ma.masked_where( labelT == 1, labelT)
a1 = np.ma.masked_where( labelP == 0, labelP)
b1 = np.ma.masked_where( labelP == 1, labelP)


# Plot the anomaly region detected for the measurement data with anomaly 
fig, ax = plt.subplots()

ax.plot(np.array(dataset_anomaly['Date']), b1,'o',markersize=3,markerfacecolor='black',markeredgecolor='black', markeredgewidth=1)
ax.plot(np.array(dataset_anomaly['Date']), a1, 'o',markersize=3,markerfacecolor='red',markeredgecolor='red', markeredgewidth=1)

leg1 = ax.legend(['Normal = 0', 'Anomaly = 1'],markerscale=3, bbox_to_anchor=(1, 0.7),framealpha=0.0);
#leg = ax.legend();


ax.tick_params(axis='x') #rotation=45
ax.set_xlabel("Time (hr)",fontsize=BIGGER_SIZE,fontweight = 'bold')
ax.set_ylabel("Anomaly Prediction",fontsize=BIGGER_SIZE,fontweight = 'bold')
#ax.set_title("Predicted Labels",fontsize=SMALL_SIZE)
ax.xaxis.set_major_formatter(mdates.DateFormatter("%#H"))
ax.xaxis.set_minor_formatter(mdates.DateFormatter("%#H"))
plt.yticks(np.arange(0, 1.5, 1))

plt.rc('font', size=MEDIUM_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=BIGGER_SIZE)
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"

right_side = ax. spines["right"]
top_side = ax. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax.spines[axis].set_linewidth(3)
    
plt.savefig('ResultPlot/Anomaly/binaryAnomalyDetectionP.pdf', bbox_inches='tight')



date_array = np.array(pd.to_datetime(dataset_anomaly['Date']))


