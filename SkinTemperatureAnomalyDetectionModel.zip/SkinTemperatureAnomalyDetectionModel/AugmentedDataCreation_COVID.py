# -*- coding: utf-8 -*-
"""
Created on Sat May  8 22:24:55 2021

@author: JJ
"""
import datetime

from pandas import read_csv

import matplotlib.pyplot as plt

import pandas as pd
from scipy import signal
from scipy.interpolate import interp1d
import numpy as np

#from datetime import datetime


import matplotlib.dates as mdates
#from datetime import datetime
import random

def low_pass_filter(data, cutoff, fs, n_taps=255):
    
    if data.shape[0] < n_taps * 3:
        raise ValueError(
            'Length of data should be three times longer than n_taps.')

    fil = signal.firwin(n_taps, cutoff, pass_zero=True, nyq=fs//2)
    modified_data = signal.filtfilt(fil, 1, data, axis=0)
    return modified_data 


SMALL_SIZE = 10
MEDIUM_SIZE = 20
BIGGER_SIZE = 20

#
##
###
# Import preparsed skin temperature measurement data with anomaly (when a heating pad is applied)
dataset = read_csv('C:/UF/TridentWearableDevice/AnomalyData/3-Day_Data.csv')

dataset['Date'] = pd.to_datetime(dataset['Date'],format='%Y%m%d_%H%M%S%f')
dataset = dataset.drop_duplicates(subset=['Date'], keep="first")
dataset=dataset.set_index('Date').resample('4S').bfill()
dataset.reset_index(inplace=True)

data_array = np.array(dataset['Skin Temp2'])
date_array = np.array(dataset['Date'])


# Low-pass filter the skin temperature measurement data with anomaly
cutoff = 1/900
fs = 5

skin_filtered = low_pass_filter(data_array, cutoff, fs, n_taps=512)





df1 = pd.DataFrame({'skin':skin_filtered})


df2 = pd.DataFrame({'Date':date_array})



anomaly = pd.concat([df2.Date, df1.skin], axis=1)

dataset=dataset.set_index('Date')
time_anomaly = dataset.index.time



df11 = anomaly
df12 = pd.DataFrame({'Time':time_anomaly})
dataset_anomaly = pd.concat([df12.Time, df11], axis=1)
dataset_anomaly = dataset_anomaly.loc[20449:21600+20449-1]
#dataset_anomaly = dataset_anomaly.loc[20449+21600*2:]
dataset_anomaly= dataset_anomaly.set_index('Time')
ind_list = dataset_anomaly.index.values

#print(ind_list)
skin_anomaly_array = np.array(dataset_anomaly['skin'])


# Import sine-fitted baseline skin temperature data
data_fit = read_csv("FittedResampled.csv")

data_fit['Date'] = pd.to_datetime(data_fit['Date'])

#print(data_fit)

data_fit = data_fit.iloc[: , 1:]
#print(data_fit)



data_fit_date_array = np.array(data_fit['Date'])
data_fit=data_fit.set_index('Date')
#print(data_fit)

time_normal = data_fit.index.time


data_fit.reset_index(inplace=True)

df1 = data_fit
df3 = pd.DataFrame({'Time':time_normal})
#print(df3)
dataset_normal = pd.concat([df3.Time, df1], axis=1)

dataset_normal= dataset_normal.set_index('Time')



# Find normal data with the same anomaly data time index
dataset_normal = dataset_normal.loc[ind_list]



dataset_normal = dataset_normal[~dataset_normal.index.duplicated(keep='first')]


dataset_normal_array = np.array(dataset_normal['Fitted'])
dataset_anomaly_array = np.array(dataset_anomaly['skin'])
 


dataset_anomaly.reset_index(inplace=True)


dataset_normal= dataset_normal.set_index('Date')

dataset_normal.reset_index(inplace=True)


date_array = np.array(dataset_anomaly['Date'])
time_array = np.array(dataset_anomaly['Time'])


# Import Predefined COVID anomaly template data 
data = read_csv('Template_augmented_data.csv')

template_array = np.array(data['TemplateTemp'])




# Import noise from baseline skin temperature meaurement data of volunteer1
Residual_dataset = read_csv("Baseline_Residual.csv")

Residual_array = np.array(Residual_dataset['Residual'])

Residual_dataset['Date'] = pd.to_datetime(Residual_dataset['Date'])


# Plot noise  
fig, ax = plt.subplots()   
ax.plot(Residual_dataset['Date'], Residual_array,'o',markersize=3,markerfacecolor='black',
     markeredgecolor='black',
     markeredgewidth=0.5, label='Anomaly template')
ax.tick_params(axis='x') #, rotation = 45
ax.xaxis.set_major_formatter(mdates.DateFormatter("%H"))
ax.xaxis.set_minor_formatter(mdates.DateFormatter("%H"))



# Find noise for one-day baseline temperature measurements
date_array = np.array(Residual_dataset['Date'])

Residual_dataset = Residual_dataset.set_index('Date')

df = pd.DataFrame({'Time':Residual_dataset.index.time})
Residual_dataset = Residual_dataset.reset_index(drop=True)

dataset = pd.concat([df, Residual_dataset['Residual']], axis=1)
dataset = dataset.applymap(str)
indexStart=dataset[dataset['Time']=='00:00:00'].index.values
indexEnd=dataset[dataset['Time']=='23:59:56'].index.values


dataset = dataset.iloc[indexStart[1]:indexEnd[2]+1]

dataset['Residual'] = dataset['Residual'].astype('float32')


residue_array=np.array(dataset['Residual'])


# Generate 100 29-day synthetic temperature data with anomaly
for m in range(0,100):    
    
    
    # Interoolate template data to smaller-size data
    x4=np.linspace(0, 29*21600-1, 29*21600) 
    f4 = interp1d(x4, template_array, kind='cubic')#29/50*14400*5 = 41760
    x_new4 = np.linspace(x4[0], x4[-1], num=41760, endpoint=True) #sample every 1 minute
    template_array_new= f4(x_new4)
    
    
    N4 = 29 
    N3 = 21600   
    new_array = np.empty([N4, N3])
    
    
    # Generate baseline temperature data with random noise captured from measurement data of Volunteer 1
    for i in range(N4):
            noise = np.reshape(residue_array,(int(N3/225),225))
            np.random.shuffle(noise)
        
        
            noise = np.reshape(noise, (N3,))
            new_array[i, :] = dataset_normal_array + noise
    
    new_normal_data_array2 = np.reshape(new_array, (N3*N4,)) 
    
    
    x2 = np.linspace(0,29*21600-1, 29*21600)
    
    
    
    # Interoolate synthetic data to lower dimension
    f1 = interp1d(x2, new_normal_data_array2, kind='cubic')
    x_new2 = np.linspace(x2[0], x2[-1], num=29*1440, endpoint=True) #sample every 1 minute
    new_normal_data_array3= f1(x_new2)
    
    cutoff=1/10
    new_normal_data_array3 = low_pass_filter(new_normal_data_array3, cutoff, fs, n_taps=128)
    
    
    
    a = random.randint(0,1440)
    c = random.uniform(0,2)
    d = random.uniform(0.98,1.02)
    #e = random.uniform(-0.1,0.1)
    new_normal_data_array3 = np.roll(new_normal_data_array3, a)
    new_normal_data_array31= new_normal_data_array3*d+template_array_new+c
    
    
   
    
    # Save the new  temperature data with COVID anomaly to Dataset0 to 99
    temp_dataset = pd. DataFrame({'Temp':new_normal_data_array31})
    date_dataset = pd. DataFrame({'Date':date_array})
    dataset = pd.concat([date_dataset, temp_dataset], axis=1)
    dataset. to_csv('AugmentedData_29Days/Dataset'+ str(m) + '.csv')

    
    
    
   
 # Generate another 100 29-day synthetic baseline temperature data 
for h in range(100, 200):    
    
        
    N4 = 29 
    N3 = 21600   
    new_array = np.empty([N4, N3])
    # Generate baseline temperature data captured from measurement data of Volunteer 1
    for i in range(N4):
            noise = np.reshape(residue_array,(int(N3/225),225))
            np.random.shuffle(noise)
        
        
            noise = np.reshape(noise, (N3,))
            new_array[i, :] = dataset_normal_array + noise
    
    new_normal_data_array2 = np.reshape(new_array, (N3*N4,)) 
    
    
    x2 = np.linspace(0,29*21600-1, 29*21600)
    
    
    # Interoolate synthetic data to lower dimension
    f1 = interp1d(x2, new_normal_data_array2, kind='cubic')
    x_new2 = np.linspace(x2[0], x2[-1], num=29*1440, endpoint=True) #sample every 1 minute
    new_normal_data_array3= f1(x_new2)
    
    cutoff=1/10
    new_normal_data_array3 = low_pass_filter(new_normal_data_array3, cutoff, fs, n_taps=128)
    
    
    # Vary the amplitude scale and offset of the new datasets to be adapted for the effect of ambient temperature
    b = random.randint(0,1440)
    d = random.uniform(0.98,1.02)
    c = random.uniform(0,2)
    #e = random.uniform(-0.1,0.1)
    new_normal_data_array3 = np.roll(new_normal_data_array3, b)
    new_normal_data_array3 = new_normal_data_array3*d+c
    
   
    
    # Save the new baseline temperature data to Dataset100 to 199
    temp_dataset = pd. DataFrame({'Temp':new_normal_data_array3})
    date_dataset = pd. DataFrame({'Date':date_array})
    dataset = pd.concat([date_dataset, temp_dataset], axis=1)
    dataset. to_csv('AugmentedData_29Days/Dataset'+ str(h) + '.csv')
    

# Generate29-day sine-fit baselineskin temperature data
N4 = 29 
N3 = 21600   
new_array_normal = np.empty([N4, N3])
for i in range(N4):
    new_array_normal[i, :] = dataset_normal_array

new_normal_array = np.reshape(new_array_normal, (N3*N4,))   


x_normal = np.linspace(0,29*21600-1, 29*21600)
f1 = interp1d(x_normal, new_normal_array, kind='cubic')
x_normal_new = np.linspace(x_normal[0], x_normal[-1], num=29*1440, endpoint=True) #sample every 1 minute
new_normal_array1= f1(x_normal_new)

new_normal_dataset = pd.DataFrame({'Temp':new_normal_array1})
new_normal_dataset.to_csv('Augmented29DaysNormalData.csv')

