# -*- coding: utf-8 -*-
"""
Created on Tue Mar 23 12:29:45 2021

@author: JJ
"""


from pandas import read_csv
from scipy import signal
from scipy.optimize import leastsq
from matplotlib.lines import Line2D
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np



def low_pass_filter(data, cutoff, fs, n_taps=255):
    
    if data.shape[0] < n_taps * 3:
        raise ValueError(
            'Length of data should be three times longer than n_taps.')

    fil = signal.firwin(n_taps, cutoff, pass_zero=True, nyq=fs//2)
    modified_data = signal.filtfilt(fil, 1, data, axis=0)
    return modified_data 



SMALL_SIZE = 10
MEDIUM_SIZE = 15
BIGGER_SIZE = 15


# Import Baseline preparsed temperature measurement data 
dataset1 = read_csv('C:/UF\TridentWearableDevice/BaselineData/Volunteer1/TemperatureData.csv')

# Convert dataframe column 'Date' to datetime
dataset1['Date']=pd.to_datetime(dataset1['Date'])


# Resample the datetime dataset to 4S with pad method for missing data
dataset1=dataset1.set_index('Date').resample('4S').pad()

Skindata = dataset1['Skin Temp1'].values

Ambientdata = dataset1['Ambient Temp'].values


cutoff = 1/3600
fs = 5


# Low-pass filter ambient temperature and skin temperature
skin_filtered1 = low_pass_filter(Skindata, cutoff, fs, n_taps=512)
ambient_filtered1 = low_pass_filter(Ambientdata, cutoff, fs, n_taps=512)


# Plot filtered ambient and skin temperature data
fig, ax = plt.subplots(2,1, constrained_layout=True)

# Plot filtered ambient and skin temperature data

ax[0].plot(dataset1.index, skin_filtered1,'o',markersize=3,markerfacecolor='white',
         markeredgecolor='blue',
         markeredgewidth=3)

ax[0].tick_params(axis='x', rotation=20,labelsize=MEDIUM_SIZE)
#ax.axis('equal')
leg = ax[0].legend();
ax[0].set_xlabel("Time", fontsize=    MEDIUM_SIZE)
ax[0].set_ylabel("Temperature ($^\circ$C)", fontsize=MEDIUM_SIZE)
ax[0].set_title("Skin Temp",fontsize=MEDIUM_SIZE)

ax[1].plot(dataset1.index, ambient_filtered1,'o',markersize=3,markerfacecolor='white',
         markeredgecolor='black',
         markeredgewidth=3)
ax[1].tick_params(axis='x', rotation=20,labelsize=MEDIUM_SIZE)
#ax.axis('equal')
leg = ax[1].legend();
ax[1].set_xlabel("Time")
ax[1].set_ylabel("Temperature ($^\circ$C)")
ax[1].set_title("Ambient Temp",fontsize=MEDIUM_SIZE)




# Fit the sin temperature data with f(t) = a*sine(bt+c)+d
offset_guess = np.mean(skin_filtered1)
amplitude_guess = 3*np.std(skin_filtered1)/(2**0.5)
frequency_guess = 1.4
phase_guess = np.pi

N = skin_filtered1.shape[0] # number of data points
N1 = 64800
t = np.linspace(0, 4*np.pi, N)
t1 = np.linspace(0, 4*np.pi, N1)

# Plot the sine fit using initial guess of the parameters
data_first_guess = amplitude_guess*np.sin(frequency_guess*t+phase_guess) + offset_guess


# Define the cost function to optimize. Here, we want to minimize the difference
# between the actual data and our "guessed" parameters
optimize_func = lambda x: x[0]*np.sin(x[1]*t+x[2]) + x[3] - skin_filtered1
est_amp, est_freq, est_phase, est_mean = leastsq(optimize_func, [amplitude_guess, frequency_guess, phase_guess, offset_guess])[0]

# Recreate the fitted curve using the optimized parameters
data_fit = est_amp*np.sin(est_freq*t+est_phase) + est_mean


# Print all optimized parameters
"""
print('a:', est_amp)
print('b:', est_freq)
print('c:', est_phase)
print('d:', est_mean)
"""


# Plot skin temperature with fitted sine-wave curve
fig, ax1 = plt.subplots()


ax1.plot(dataset1.index, skin_filtered1,'o',markersize=3,markerfacecolor='blue',
         markeredgecolor='blue',
         markeredgewidth=1, label='Skin Temp')
ax1.plot(dataset1.index, data_fit,'o',markersize=3,markerfacecolor='red',
         markeredgecolor='red',
         markeredgewidth=1,label='Sine-fit')

ax1.tick_params(axis='x', rotation=45, labelsize=MEDIUM_SIZE)
ax1.tick_params(axis='y', labelsize=MEDIUM_SIZE)

line1 = Line2D(range(1), range(1), color="white", marker='o',markersize=8, markerfacecolor="blue")
line2 = Line2D(range(1), range(1), color="white", marker='o',markersize=8, markerfacecolor="red")
leg = ax1.legend([line1,line2],['Skin Temp', 'Sine-fit'],bbox_to_anchor=(0.9, 1), loc='upper left',framealpha=0.0,fontsize=BIGGER_SIZE, prop={'weight':'bold'});
ax1.set_xlabel("Date and Time", fontweight = 'bold',fontsize=MEDIUM_SIZE)
ax1.set_ylabel("Temperature (\N{DEGREE SIGN}C)", fontweight = 'bold',fontsize=MEDIUM_SIZE)

right_side = ax1. spines["right"]
top_side = ax1. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax1.spines[axis].set_linewidth(3)
fig.savefig('dailycycle.pdf', bbox_inches='tight')

Residue=skin_filtered1-data_fit
df1 = pd.DataFrame({'Residual':Residue})
df2 = pd.DataFrame({'Date':dataset1.index})
data = pd.concat([df2.Date, df1], axis=1)

# Save all the resampled and fitted temperature data (normal data)

data.to_csv('Baseline_Residual.csv')


df1 = pd.DataFrame({'Fitted':data_fit})
df2 = pd.DataFrame({'Date':dataset1.index.values})
df2['Date'] = pd. DatetimeIndex(df2['Date']).tz_localize('UTC').tz_convert('US/Eastern')
fit = pd.concat([df2.Date, df1.Fitted], axis=1)

# Save all the resampled and fitted temperature data (normal data)

fit.to_csv("FittedResampled.csv")




# Import preparsed skin temperature measurement data with anomaly (when a heating pad is applied)
dataset = read_csv('C:/UF/TridentWearableDevice/AnomalyData/3-Day_Data.csv')




dataset['Date'] = pd.to_datetime(dataset['Date'],format='%Y%m%d_%H%M%S%f')
dataset = dataset.drop_duplicates(subset=['Date'], keep="first")
dataset=dataset.set_index('Date').resample('4S').bfill()
dataset.reset_index(inplace=True)

data_array = np.array(dataset['Skin Temp2'])
amibent_data_array = np.array(dataset['AmbientB'])


date_array = np.array(dataset['Date'])

# Low-pass filter measurement data with anomaly
cutoff = 1/3600
fs = 5

skin_filtered = low_pass_filter(data_array, cutoff, fs, n_taps=512)






# Plot filtered skin measurement data with anomaly
fig, ax = plt.subplots()

ax.plot(date_array, skin_filtered,'o',markersize=3,markerfacecolor='white',
         markeredgecolor='blue',
         markeredgewidth=3, label='Skin')
ax.tick_params(axis='x', rotation=20,labelsize=MEDIUM_SIZE)

leg = ax.legend();
ax.set_xlabel("Time",fontsize=MEDIUM_SIZE)
ax.set_ylabel("Temperature",fontsize=MEDIUM_SIZE)
ax.set_title("Skin Temp1",fontsize=MEDIUM_SIZE)



# Plot filtered ambient measurement data 
fig, ax = plt.subplots()
ax.plot(date_array, amibent_data_array,'o',markersize=3,markerfacecolor='white',
         markeredgecolor='black',
         markeredgewidth=3, label='Ambient')
ax.tick_params(axis='x', rotation=20,labelsize=MEDIUM_SIZE)

leg = ax.legend();
ax.set_xlabel("Time",fontsize=MEDIUM_SIZE)
ax.set_ylabel("Temperature",fontsize=MEDIUM_SIZE)
ax.set_title("Ambient Temp",fontsize=MEDIUM_SIZE)


# Save filtered skin temperature data with anomaly (anomalous data)
df1 = pd.DataFrame({'skin':skin_filtered})


df2 = pd.DataFrame({'Date':date_array})

anomaly = pd.concat([df2.Date, df1.skin], axis=1)
anomaly.to_csv("AnomalResampled.csv")

dataset=dataset.set_index('Date')





# Find anomaly data indices in normal data
time_normal = dataset1.index.time
time_anomaly = dataset.index.time


df1 = fit
df2 = pd.DataFrame({'Time':time_normal})
dataset_normal = pd.concat([df2.Time, df1], axis=1)
dataset_normal= dataset_normal.set_index('Time')



df11 = anomaly
df12 = pd.DataFrame({'Time':time_anomaly})
dataset_anomaly = pd.concat([df12.Time, df11], axis=1)
dataset_anomaly = dataset_anomaly.loc[21600*3:]
dataset_anomaly= dataset_anomaly.set_index('Time')
ind_list = dataset_anomaly.index.values


# Find normal data with the sme anomalous data time index for synchronization of normal and anomalous data set
dataset_normal = dataset_normal.loc[ind_list]

dataset_normal = dataset_normal[~dataset_normal.index.duplicated(keep='first')]


dataset_normal_array = np.array(dataset_normal['Fitted'])
dataset_anomaly_array = np.array(dataset_anomaly['skin'])


# Find difference between anomalous and normal measurement data for generating anomaly template
diff = dataset_anomaly_array - dataset_normal_array
diff = low_pass_filter(diff, cutoff, fs, n_taps=512)


# Plot the difference
fig, ax = plt.subplots()


ax.plot(dataset_anomaly['Date'], diff,'o',markersize=3,markerfacecolor='white',
         markeredgecolor='blue',
         markeredgewidth=3, label='skin')

ax.tick_params(axis='x', rotation=20,labelsize=MEDIUM_SIZE)

leg = ax.legend();
ax.set_xlabel("Time",fontsize=MEDIUM_SIZE)
ax.set_ylabel("Temperature",fontsize=MEDIUM_SIZE)
ax.set_title("Anomaly - Fitted Normal",fontsize=MEDIUM_SIZE)

# Define the true anomaly in one-day anomalous temperature data
dataset_anomaly.reset_index(inplace=True)
dataset_normal.reset_index(inplace=True)
date_array = np.array(dataset_anomaly['Date'])
indexStart=dataset_anomaly[dataset_anomaly['Date']=='2021-04-06 10:47:00'].index.values
indexEnd=dataset_anomaly[dataset_anomaly['Date']=='2021-04-06 14:05:00'].index.values



date_arrayhp=date_array[indexStart[0]:indexEnd[0]]
diffhp = diff[indexStart[0]:indexEnd[0]]

ax.plot(date_arrayhp, diffhp,'o',markersize=3,markerfacecolor='white',
         markeredgecolor='red',
         markeredgewidth=3)

# Plot one-day normal temperature measurement data
fig, ax = plt.subplots()
ax.plot(date_array, dataset_normal_array,'o',markersize=3,markerfacecolor='white',
         markeredgecolor='red',
         markeredgewidth=3, label='skin')

# Plot true anomaly along with one-day anomalous data
fig, ax0 = plt.subplots()

ax0.plot(date_array, dataset_anomaly_array,'o',markersize=3,markerfacecolor='white',
         markeredgecolor='blue',
         markeredgewidth=3)

ax.tick_params(axis='x', rotation=45,labelsize=MEDIUM_SIZE)

leg = ax.legend();
ax.set_xlabel("Time",fontsize=MEDIUM_SIZE)
ax.set_ylabel("Temperature",fontsize=MEDIUM_SIZE)
ax.set_title("Skin Temp",fontsize=MEDIUM_SIZE)




# Fit normalized anomaly patterns from heating pad with eponential decay curves.
def expwave(t, a1, b1, width1, a2, b2):
    y=np.empty([2970+400])
    for i in range(N):
        
        if (t[i] < width1):
            y[i]=a1*(1-np.exp(-t[i]/b1))
        else:
            y[i]=a2*np.exp(-(t[i]-width1)/b2)
    
    return y



n= indexEnd[0] - indexStart[0]+400
t = np.empty([n])
def extend(x,offset):
    y=t
    y[n-400:n] =offset
    y[0:n-400]=x
    return y


date_arrayhp1=date_array[indexStart[0]:indexEnd[0]+400]


diffhp = extend(diffhp, diffhp[-1])

diffhp_scaled = (diffhp-np.min(diffhp))/(np.max(diffhp)-np.min(diffhp))

N = diffhp_scaled.shape[0] # number of data points


t = np.linspace(0, N, N)
t1 = np.empty([N])



a1_guess=0.91
b1_guess=301
width1_guess = 2605

a2_guess=0.91
b2_guess= 170
#width2 = N/4


# Use this for intial guess of the exponential fit curve parameters
data_guess = expwave(t, a1_guess, b1_guess, width1_guess, a2_guess, b2_guess)



# Define the function to optimize and minimize the difference
# between the actual data and our "guessed" parameters
optimize_func = lambda x:  expwave(t, x[0], x[1], x[2], x[3], x[4])- diffhp_scaled

est_a1, est_b1,  est_width1, est_a2, est_b2= leastsq(optimize_func, [a1_guess, b1_guess, width1_guess,  a2_guess, b2_guess])[0]

# recreate the fitted curve using the optimized parameters
data_fita = expwave(t, est_a1, est_b1,  est_width1, est_a2, est_b2) # 0.0002, 75,  N/3, 0.6, 445.06, 100, -442.83


x = np.linspace(0,3370, 3370)


# Plot the the expoenential fit curve on top of the normalized anomaly pattern 
fig, ax = plt.subplots()

ax.plot(x, diffhp_scaled,'o',markersize=3,markerfacecolor='black',
         markeredgecolor='black',
         markeredgewidth=3, label='Temperature meaurement anomaly ')

ax.plot(x, data_fita,'o',markersize=3,markerfacecolor='red',
         markeredgecolor='red',
         markeredgewidth=3, label='Exponential fit')



#ax.xaxis.set_major_formatter(mdates.DateFormatter("%#H"))
#ax.xaxis.set_minor_formatter(mdates.DateFormatter("%#H"))
ax.tick_params(axis='x') 

ax.set_xticks([0, 900, 1800, 2700])

ax.set_xticklabels([0, 1, 2, 3])
ax.tick_params(axis='x', rotation=45,labelsize=MEDIUM_SIZE)

leg = ax.legend(markerscale=3,  bbox_to_anchor=(1, 1.3),framealpha=0.0,fontsize=MEDIUM_SIZE);
ax.set_xlabel("Time (hr)",fontsize=BIGGER_SIZE,fontweight = 'bold')
ax.set_ylabel("Normalized Temperature",fontsize=BIGGER_SIZE,fontweight = 'bold')


plt.rc('font', size=MEDIUM_SIZE)          
plt.rc('axes', titlesize=BIGGER_SIZE)
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"

right_side = ax. spines["right"]
top_side = ax. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax.spines[axis].set_linewidth(3)
    
    
plt.savefig('ResultPlot/Anomaly/Anomaly Template.pdf', bbox_inches='tight')    



# Save the anomaly template (exponetial fit curves)
residue_3hour = diffhp_scaled-data_fita
data_residue_3hour = pd.DataFrame({'Residue':residue_3hour})

datafita = pd.DataFrame({'Skin':data_fita})

datearray = pd.DataFrame(date_arrayhp,columns=['a'])

template = pd.concat([datearray, datafita], axis=1)
template.to_csv('Template_scaled.csv')

