# -*- coding: utf-8 -*-
"""
Created on Wed May 12 21:33:35 2021

@author: JJ
"""
#from collections import Counter

from pandas import read_csv
from sklearn.preprocessing import MinMaxScaler
from scipy import signal
from scipy.interpolate import interp1d
import numpy as np




def low_pass_filter(data, cutoff, fs, n_taps):
    
    if data.shape[0] < n_taps * 3:
        raise ValueError(
            'Length of data should be three times longer than n_taps.')

    fil = signal.firwin(n_taps, cutoff, pass_zero=True, nyq=fs//2)
    modified_data = signal.filtfilt(fil, 1, data, axis=0)
    return modified_data 


def extend(x,offset, t2, indexStart, indexEnd, N):
    y=t2
    y[0:indexStart]=offset
    y[indexEnd:N]=offset
    y[indexStart: indexEnd]=x
    return y

SMALL_SIZE = 10
MEDIUM_SIZE = 15
BIGGER_SIZE = 15

cutoff = 1/900
fs = 5
n_taps = 1024

# Import COVID anomaly template data
data = read_csv('Template_augmented_data.csv')
kernel_array = np.array(data['TemplateTemp'])



N=5*14400
t2=np.empty([N])
offset = kernel_array[0]
indexStart = 8000
indexEnd   = indexStart+41760

# Interpolate COVID  anomaly template data
x1=np.linspace(0, 29*21600-1, 29*21600) 
f1 = interp1d(x1, kernel_array, kind='cubic')#29/50*14400*5 = 41760
x_new1 = np.linspace(x1[0], x1[-1], num=41760, endpoint=True) #sample every 1 minute
kernel_array_new= f1(x_new1)


# Remove noise and normalize template data 
cutoff = 1/100
#kernel_array_new = extend(kernel_array_new,offset, t2, indexStart, indexEnd, N)

kernel_array_new = low_pass_filter(kernel_array_new, cutoff, fs, 512)

kernel_array_new = np.reshape(kernel_array_new, (kernel_array_new.shape[0],1))
# define min max scaler
scaler = MinMaxScaler()
# transform data
kernel_array_new_scaled = scaler.fit_transform(kernel_array_new)

# Set threshold value
threshold_value=11000
threshold = threshold_value*np.ones((kernel_array_new.shape[0]))

num=200
FPR = np.empty([num,1])
FNR = np.empty([num,1])
TPR = np.empty([num,1])
TNR = np.empty([num,1])


# Import all 29-day sine-fit baseline skin temperature data 
normal_dataset = read_csv('Augmented29DaysNormalData.csv')
normal_data_array = np.array(normal_dataset['Temp'])

m=29
indexEnd =int(m* 1440)


labelT=np.zeros((num,1))
labelP=np.zeros((num,1))
dt=np.zeros((num,1))
duration = int(1440*2) #  2 Day over the convolution threshold as a detection criteria
cn = 0

# Find the detection time and anomaly prediction result of each dataset
for i in range(num):
    
    # Import each sythetic data set
    testdataset = read_csv('AugmentedData_29Days1/Dataset' + str(i) + '.csv')
    test_data = testdataset['Temp']
    
    # Find difference between augmented testing skin temperature data and sine-fit baselien data
    test_data_array = np.array(test_data)
    test_data_array = test_data_array - normal_data_array
    

    test_data_array = np.reshape(test_data_array, (test_data_array.shape[0],1))
    
    def running_mean(x, N):
        cumsum = np.cumsum(np.insert(x, 0, 0)) 
        return (cumsum[N:] - cumsum[:-N]) / float(N)

    N=1440
    
    # Run moving avergae on the testing data to remove noise and then normalize the data
    test_data_array_filtered = running_mean(test_data_array, N)
    
    test_data_array_filtered = np.reshape(test_data_array_filtered, (test_data_array_filtered.shape[0],1))
    
    scaler = MinMaxScaler()
    test_data_scaled = scaler.fit_transform(test_data_array_filtered)
    kernel_array_new_scaled = np.reshape(kernel_array_new_scaled, (kernel_array_new_scaled.shape[0],))
    test_data_scaled = np.reshape(test_data_scaled, (test_data_scaled.shape[0],))
    
   
    print('Computing...')
    
    cn=cn+1
    print(cn)
    
    
    # Report the convolution results when convolving the normalized COVID template data with the testing data
    report = signal.fftconvolve(test_data_scaled, kernel_array_new_scaled, 'same')
    
    
    # Find the convolutional result at the anomaly detection time
    report = report[0:indexEnd]
    
    
    
    #True labels
    labelT[0:int(num/2)]= np.ones([int(num/2),1])
    
    
    # Find out whether the convolutional results are above the the preset threshold for the period of 'duration'
    diff =report-np.ones([report.shape[0]])*threshold_value
    def is_straight(playerHand, duration):
        #playerHand.sort()
        for j in range(duration):
            if playerHand[j] != playerHand [j+1] - 1:
                return False
        return True
    
    if any(x>0 for x in diff):
        indexP = np.where(diff>0)[0]
        #print(indexP)
        if duration<indexP.shape[0]:
            Boolean = is_straight(indexP, duration)
            if Boolean:
                labelP[i]=1
                print('positive')
                
                # Print the detection time before peak
                dt[i] = (indexP[0]+duration-15*1440)/1440
                print('Days before Peak:', dt[i])
            else:
                labelP[i]=0
        else:
           labelP[i]=0 
    else:
        labelP[i]=0
        
    #print(diff)
    
    
    
    
 # Find the detection time mean and standardard deviation for all 200 datasets   
dt = dt[dt!=0]
mu = np.mean(dt)
std = np.std(dt)
print('mean:', mu)
print('standard deviation:', std)


# Find the true negative,false positive, true positive and false negative results based on the anomaly detection of the 200 datasets
TN = ((1-labelP)*(1-labelT)).sum()
TP = ((labelP)*(labelT)).sum()
FN = ((1-labelP)*(labelT)).sum()
FP = ((labelP)*(1-labelT)).sum()
   
# Find TPR, TNR, FPR and FNR
if FP == 0:
    FPR = 0
else:
    FPR = FP/(FP+TN)
if FN == 0:    
    FNR = 0
else:
    FNR = FN/(FN+TP)
if TP == 0:
    TPR = 0
else:
    TPR = TP/(TP+FN)
if TN == 0:    
    TNR = 0
else:
    TNR = TN/(TN+FP)

print(FP)
print(TP)
print(FN)
print(TN)

print('FPR:',FPR)
print('TPR:',TPR)
print('FNR:',FNR)
print('TNR:',TNR)


    