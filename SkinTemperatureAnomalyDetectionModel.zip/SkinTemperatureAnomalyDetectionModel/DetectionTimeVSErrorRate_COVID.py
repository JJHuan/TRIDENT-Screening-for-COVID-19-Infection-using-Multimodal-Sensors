# -*- coding: utf-8 -*-
"""
Created on Thu May 13 13:52:46 2021
@author: JJ
"""

import matplotlib.pyplot as plt
import numpy as np

# Repeat running AugmentedDataAnomalyDetection_COVID.py for 5 times by varying detection criteria (detection time)
# based on the two thresholds that generate the optimum prediction accuracy


##Dataset1
#Threshold = 11500

Day_mean1 = [-1.08, -0.08, 0.88, 1.88, 2.84]
Day_std1 = [1.13, 1.13, 1.07, 1.07, 1.03]
    
FPR1 =np.array ([0.1, 0.1, 0.1, 0.1, 0.09])
TPR1 =np.array ([1, 1, 0.99, 0.99, 0.98])   
FNR1 = np.array ([0, 0, 0.01, 0.01, 0.02])    
TNR1 = np.array ([0.9, 0.9, 0.9, 0.9, 0.91])


#Threshold = 11000

Day_mean11 = [-1.77, -0.82, 0.18, 1.17, 2.14]
Day_std11 = [1.18, 1.14, 1.14, 1.13, 1.11]
    
FPR11 =np.array ([0.26, 0.24, 0.24, 0.23, 0.18])
TPR11 =np.array ([1, 1, 1, 1, 0.99])   
FNR11 = np.array ([0, 0, 0, 0, 0.01])    
TNR11 = np.array ([0.74, 0.76, 0.76, 0.77, 0.82])

##Dataset2
#Threshold = 11500

Day_mean2 = [-0.93, 0.07, 1.06, 2.06, 3.01]
Day_std2 = [1.12, 1.12, 1.19, 1.119, 1.07]
    
FPR2 =np.array ([0.09, 0.09, 0.08, 0.08, 0.08])
TPR2 =np.array ([0.98, 0.98, 0.98, 0.98, 0.96])   
FNR2 = np.array ([0.02, 0.02, 0.02, 0.02, 0.04])    
TNR2 = np.array ([0.91, 0.91, 0.92, 0.92, 0.92])

#Threshold = 11000
Day_mean21 = [-1.6, -0.61, 0.39, 1.34, 2.28]
Day_std21 = [1.23, 1.22, 1.22, 1.17, 1.11]
    
FPR21 =np.array ([0.2, 0.19, 0.19, 0.18, 0.16])
TPR21 =np.array ([1, 1, 1, 0.99, 0.98])   
FNR21 = np.array ([0, 0, 0, 0.01, 0.02])    
TNR21 = np.array ([0.8, 0.81, 0.81, 0.82, 0.84])   

##Dataset3
#Threshold = 11500

Day_mean3 = [-1.23, -0.23, 0.73, 1.7, 2.67]
Day_std3 = [1.118, 1.118, 1.05, 0.99, 0.95]
    
FPR3 =np.array ([0.15, 0.15, 0.15, 0.15, 0.15])
TPR3 =np.array ([1, 1, 0.99, 0.98, 0.97])   
FNR3 = np.array ([0, 0, 0.01, 0.02, 0.03])    
TNR3 = np.array ([0.85, 0.85, 0.85, 0.85, 0.85])

#Threshold = 11000
Day_mean31 = [-2, -1.02, -0.02, 0.94, 1.93]
Day_std31 = [1.71, 1.16, 1.16, 1.13, 1.12]
    
FPR31 =np.array ([0.24, 0.23, 0.23, 0.21, 0.2])
TPR31 =np.array ([1, 1, 1, 1, 1])   
FNR31 = np.array ([0, 0, 0, 0, 0])    
TNR31 = np.array ([0.76, 0.77, 0.77, 0.79, 0.8])  

##Dataset4
#Threshold = 11500

Day_mean4 = [-0.83, 0.17, 1.18, 2.15, 3.09]
Day_std4 = [1.056, 1.06, 1.05, 1.01, 0.94]
    
FPR4 =np.array ([0.07, 0.07, 0.07, 0.07, 0.07])
TPR4 =np.array ([0.99, 0.99, 0.99, 0.98, 0.96])   
FNR4 = np.array ([0.01, 0.01, 0.01, 0.02, 0.04])    
TNR4 = np.array ([0.93, 0.93, 0.93, 0.93, 0.93])

#Threshold = 11000
Day_mean41 = [-1.55, -0.59, 0.41, 1.41, 2.4]
Day_std41 = [1.07, 1.004, 1.005, 1.005, 1]
    
FPR41 =np.array ([0.23, 0.21, 0.21, 0.21, 0.2])
TPR41 =np.array ([0.99, 0.99, 0.99, 0.99, 0.99])   
FNR41 = np.array ([0.01, 0.01, 0.01, 0.01, 0.01])    
TNR41 = np.array ([0.77, 0.79, 0.79, 0.79, 0.8])  


##Dataset5
#Threshold = 11500

Day_mean5 = [-0.94, 0.075, 1.075, 2.075, 3.04]
Day_std5 = [1.026, 1.025, 1.025, 1.025, 0.998]
    
FPR5 =np.array ([0.09, 0.09, 0.09, 0.09, 0.08])
TPR5 =np.array ([1, 1, 1, 1, 0.99])   
FNR5 = np.array ([0, 0, 0, 0, 0.01])    
TNR5 = np.array ([0.91, 0.91, 0.91, 0.91, 0.92])

#Threshold = 11000
Day_mean51 = [-1.657, -0.66, 0.32,  1.29, 2.25]
Day_std51 = [1.08, 1.08, 1.06, 1.04, 1.01]
    
FPR51 =np.array ([0.22, 0.22, 0.21, 0.19, 0.17])
TPR51 =np.array ([1, 1, 1, 1, 1])   
FNR51 = np.array ([0, 0, 0, 0, 0])    
TNR51 = np.array ([0.78, 0.78, 0.79, 0.81, 0.83]) 


# Find detection time and fault rate errors to plot error bars
##Threshold =11500
DayP1 = [Day_mean1[1], Day_mean2[1], Day_mean3[1], Day_mean4[1], Day_mean5[1]]
DayP2 = [Day_mean1[2], Day_mean2[2], Day_mean3[2], Day_mean4[2], Day_mean5[2]]
DayP3 = [Day_mean1[3], Day_mean2[3], Day_mean3[3], Day_mean4[3], Day_mean5[3]]
DayP4 = [Day_mean1[4], Day_mean2[4], Day_mean3[4], Day_mean4[4], Day_mean5[4]]
DayP0 = [Day_mean1[0], Day_mean2[0], Day_mean3[0], Day_mean4[0], Day_mean5[0]]

Day_mean = [np.mean(DayP0),np.mean(DayP1), np.mean(DayP2), np.mean(DayP3), np.mean(DayP4)]


DayP1s = [Day_std1[1], Day_std2[1], Day_std3[1], Day_std4[1], Day_std5[1]]
DayP2s = [Day_std1[2], Day_std2[2], Day_std3[2], Day_std4[2], Day_std5[2]]
DayP3s = [Day_std1[3], Day_std2[3], Day_std3[3], Day_std4[3], Day_std5[3]]
DayP4s = [Day_std1[4], Day_std2[4], Day_std3[4], Day_std4[4], Day_std5[4]]
DayP0s = [Day_std1[0], Day_std2[0], Day_std3[0], Day_std4[0], Day_std5[0]]


Day_std = [np.mean(DayP0s), np.mean(DayP1s), np.mean(DayP2s), np.mean(DayP3s), np.mean(DayP4s)]


xerr = Day_std

FPRP1 = [FPR1[1], FPR2[1], FPR3[1], FPR4[1], FPR5[1]]
FPRP2 = [FPR1[2], FPR2[2], FPR3[2], FPR4[2], FPR5[2]]
FPRP3 = [FPR1[3], FPR2[3], FPR3[3], FPR4[3], FPR5[3]]
FPRP4 = [FPR1[4], FPR2[4], FPR3[4], FPR4[4], FPR5[4]]
FPRP0 = [FPR1[0], FPR2[0], FPR3[0], FPR4[0], FPR5[0]]

FPR_mean = [np.mean(FPRP0), np.mean(FPRP1), np.mean(FPRP2), np.mean(FPRP3), np.mean(FPRP4)]

FPR_std = [np.std(FPRP0), np.std(FPRP1), np.std(FPRP2), np.std(FPRP3), np.std(FPRP4)]
yerr1 = FPR_std


FNRP1 = [FNR1[1], FNR2[1], FNR3[1], FNR4[1], FNR5[1]]
FNRP2 = [FNR1[2], FNR2[2], FNR3[2], FNR4[2], FNR5[2]]
FNRP3 = [FNR1[3], FNR2[3], FNR3[3], FNR4[3], FNR5[3]]
FNRP4 = [FNR1[4], FNR2[4], FNR3[4], FNR4[4], FNR5[4]]
FNRP0 = [FNR1[0], FNR2[0], FNR3[0], FNR4[0], FNR5[0]]

FNR_mean = [np.mean(FNRP0), np.mean(FNRP1), np.mean(FNRP2), np.mean(FNRP3), np.mean(FNRP4)]

FNR_std = [np.std(FNRP0), np.std(FNRP1), np.std(FNRP2), np.std(FNRP3), np.std(FNRP4)]
yerr2 = FNR_std


##Threshold =11000
DayP11 = [Day_mean11[1], Day_mean21[1], Day_mean31[1], Day_mean41[1], Day_mean51[1]]
DayP21 = [Day_mean11[2], Day_mean21[2], Day_mean31[2], Day_mean41[2], Day_mean51[2]]
DayP31 = [Day_mean11[3], Day_mean21[3], Day_mean31[3], Day_mean41[3], Day_mean51[3]]
DayP41 = [Day_mean11[4], Day_mean21[4], Day_mean31[4], Day_mean41[4], Day_mean51[4]]
DayP01 = [Day_mean11[0], Day_mean21[0], Day_mean31[0], Day_mean41[0], Day_mean51[0]]

Day_mean1 = [np.mean(DayP01),np.mean(DayP11), np.mean(DayP21), np.mean(DayP31), np.mean(DayP41)]


DayP11s = [Day_std11[1], Day_std21[1], Day_std31[1], Day_std41[1], Day_std51[1]]
DayP21s = [Day_std11[2], Day_std21[2], Day_std31[2], Day_std41[2], Day_std51[2]]
DayP31s = [Day_std11[3], Day_std21[3], Day_std31[3], Day_std41[3], Day_std51[3]]
DayP41s = [Day_std11[4], Day_std21[4], Day_std31[4], Day_std41[4], Day_std51[4]]
DayP01s = [Day_std11[0], Day_std21[0], Day_std31[0], Day_std41[0], Day_std51[0]]


Day_std1 = [np.mean(DayP01s), np.mean(DayP11s), np.mean(DayP21s), np.mean(DayP31s), np.mean(DayP41s)]


xerr1 = Day_std1

FPRP11 = [FPR11[1], FPR21[1], FPR31[1], FPR41[1], FPR51[1]]
FPRP21 = [FPR11[2], FPR21[2], FPR31[2], FPR41[2], FPR51[2]]
FPRP31 = [FPR11[3], FPR21[3], FPR31[3], FPR41[3], FPR51[3]]
FPRP41 = [FPR11[4], FPR21[4], FPR31[4], FPR41[4], FPR51[4]]
FPRP01 = [FPR11[0], FPR21[0], FPR31[0], FPR41[0], FPR51[0]]

FPR_mean1 = [np.mean(FPRP01), np.mean(FPRP11), np.mean(FPRP21), np.mean(FPRP31), np.mean(FPRP41)]

FPR_std1 = [np.std(FPRP01), np.std(FPRP11), np.std(FPRP21), np.std(FPRP31), np.std(FPRP41)]
yerr11 = FPR_std1


FNRP11 = [FNR11[1], FNR21[1], FNR31[1], FNR41[1], FNR51[1]]
FNRP21 = [FNR11[2], FNR21[2], FNR31[2], FNR41[2], FNR51[2]]
FNRP31 = [FNR11[3], FNR21[3], FNR31[3], FNR41[3], FNR51[3]]
FNRP41 = [FNR11[4], FNR21[4], FNR31[4], FNR41[4], FNR51[4]]
FNRP01 = [FNR11[0], FNR21[0], FNR31[0], FNR41[0], FNR51[0]]

FNR_mean1 = [np.mean(FNRP01), np.mean(FNRP11), np.mean(FNRP21), np.mean(FNRP31), np.mean(FNRP41)]

FNR_std1 = [np.std(FNRP01), np.std(FNRP11), np.std(FNRP21), np.std(FNRP31), np.std(FNRP41)]
yerr21 = FNR_std1




SMALL_SIZE = 10
MEDIUM_SIZE = 15
BIGGER_SIZE = 15


# Plot FNR and FPR over detection time before anomaly peak (the 15th day) based on the two optimum detection threshold
fig, ax = plt.subplots()
ax.plot(Day_mean,FNR_mean,'o',markersize=5,markerfacecolor='black',
         markeredgecolor='black',
         markeredgewidth=5, label='FNR (detection threshold 1)')
ax.plot(Day_mean,FNR_mean, color='black',linewidth=3)

ax.errorbar(Day_mean, FNR_mean, xerr=xerr, yerr=yerr2,  fmt='k', capsize=5)

ax.plot(Day_mean1,FNR_mean1,'o',markersize=5,markerfacecolor='blue',
         markeredgecolor='blue',
         markeredgewidth=5, label='FNR (detection threshold 2)')
ax.plot(Day_mean1,FNR_mean1, color='blue',linewidth=3)

ax.errorbar(Day_mean1, FNR_mean1, xerr=xerr1, yerr=yerr21,  fmt='b', capsize=5)


leg = ax.legend(bbox_to_anchor=(0.8, 1.3),framealpha=0.0,fontsize=MEDIUM_SIZE);
#ax.set_xticks(np.arange(0, len(Threshold)+1, 100))

ax.tick_params(axis='x')

ax.set_xlabel("Days Before Anomaly Peak",fontsize=BIGGER_SIZE,fontweight = 'bold')
ax.set_ylabel("False Negative Rate",fontsize=BIGGER_SIZE,fontweight = 'bold')
#ax.set_title("ROC Curve",fontsize=SMALL_SIZE)

plt.rc('font', size=MEDIUM_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=BIGGER_SIZE)
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"

#lt.yticks(np.arange(0, max(y), 2))

right_side = ax. spines["right"]
top_side = ax. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax.spines[axis].set_linewidth(3)
plt.savefig('ResultPlot/FNRVSDetectionTime.pdf', bbox_inches='tight')


fig, ax = plt.subplots()
ax.plot(Day_mean,FPR_mean,'o',markersize=5,markerfacecolor='black',
         markeredgecolor='black',
         markeredgewidth=5, label='FPR (detection threshold 1)')
ax.plot(Day_mean,FPR_mean, color='black',linewidth=3)

ax.errorbar(Day_mean, FPR_mean, xerr=xerr, yerr=yerr1,  fmt='k', capsize=5)

ax.plot(Day_mean1,FPR_mean1,'o',markersize=5,markerfacecolor='blue',
         markeredgecolor='blue',
         markeredgewidth=5, label='FPR (detection threshold 2)')
ax.plot(Day_mean1,FPR_mean1, color='blue',linewidth=3)

ax.errorbar(Day_mean1, FPR_mean1, xerr=xerr1, yerr=yerr11,  fmt='b', capsize=5)
#leg = ax.legend(bbox_to_anchor=(0.5, 0.7), loc='upper left',framealpha=0.0,fontsize=MEDIUM_SIZE);
#ax.set_xticks(np.arange(0, len(Threshold)+1, 100))
leg = ax.legend(markerscale=1,  bbox_to_anchor=(0.8, 1.3),framealpha=0.0,fontsize=MEDIUM_SIZE);
ax.tick_params(axis='x')

ax.set_xlabel("Days Before Anomaly Peak",fontsize=BIGGER_SIZE,fontweight = 'bold')
ax.set_ylabel("False Positive Rate",fontsize=BIGGER_SIZE,fontweight = 'bold')
#ax.set_title("ROC Curve",fontsize=SMALL_SIZE)

plt.rc('font', size=MEDIUM_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=BIGGER_SIZE)
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"

#lt.yticks(np.arange(0, max(y), 2))

right_side = ax. spines["right"]
top_side = ax. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax.spines[axis].set_linewidth(3)
    
    
plt.savefig('ResultPlot/FPRVSDetectionTime.pdf', bbox_inches='tight')


