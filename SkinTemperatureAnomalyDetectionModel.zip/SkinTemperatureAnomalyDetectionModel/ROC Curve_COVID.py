# -*- coding: utf-8 -*-
"""
Created on Thu May 13 13:52:46 2021
@author: JJ
"""

import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import auc


# Lists of fault rates based on different threshold to generate an ROCvurve.
##1Day detected over threshold
Threshold2 = [8000, 9000, 9400, 9700, 10000, 10250, 10500, 11000, 11250, 11500, 12000, 12500, 13000, 13250, 13500, 13750, 14000, 15000]
FPR2= np.array([1, 0.92, 0.81, 0.71, 0.59, 0.48, 0.4, 0.2, 0.11, 0.09, 0.05, 0, 0, 0, 0, 0, 0, 0])
TPR2 = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 0.98, 0.96, 0.87, 0.66, 0.56, 0.46, 0.35, 0.24, 0])
FNR2 = np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0.02, 0.04, 0.13, 0.34, 0.44, 0.54, 0.65, 0.76, 0.99])
TNR2 = np.array([0, 0.08, 0.19, 0.29, 0.41, 0.52, 0.6, 0.8, 0.89, 0.91, 0.95, 1, 1, 1, 1, 1, 1, 1])

##1Day detected over threshold
Threshold3 = [8000, 9000, 9400, 9700, 10000, 10250, 10500, 11000, 11250, 11500, 12000, 12500, 13000, 13250, 13500, 13750, 14000, 15000]
FPR3 = np.array([0.99, 0.89, 0.82, 0.75, 0.65, 0.5, 0.37, 0.24, 0.18, 0.15, 0.05, 0.02, 0, 0, 0, 0, 0, 0])
TPR3 = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.97, 0.94, 0.87, 0.76, 0.55, 0.39, 0.25, 0.01])
FNR3 = np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.03, 0.06, 0.13, 0.24, 0.45, 0.61, 0.75, 0.99])
TNR3 = np.array([0.01, 0.11, 0.18, 0.25, 0.35, 0.5, 0.63, 0.76, 0.82, 0.85, 0.95, 0.98, 1, 1, 1, 1, 1, 1])

##1Day detected over threshold
Threshold4 = [8000, 9000, 9400, 9700, 10000, 10250, 10500, 11000, 11250, 11500, 12000, 12500, 13000, 13250, 13500, 13750, 14000, 15000]
FPR4 = np.array([1, 0.94, 0.82, 0.75, 0.73, 0.63, 0.45, 0.23, 0.13, 0.07, 0.04, 0, 0, 0, 0, 0, 0, 0])
TPR4 = np.array([1, 1, 1, 1, 1, 1, 1, 0.99, 0.99, 0.99, 0.96, 0.89, 0.67, 0.54, 0.37, 0.25, 0.12, 0.01])
FNR4 = np.array([0, 0, 0, 0, 0, 0, 0, 0.01, 0.01, 0.01, 0.04, 0.11, 0.33, 0.46, 0.63, 0.75, 0.88, 0.09])
TNR4 = np.array([0, 0.06, 0.18, 0.25, 0.27, 0.37, 0.55, 0.77, 0.87, 0.93, 0.96, 1, 1, 1, 1, 1, 1, 1])

##1Day detected over threshold
Threshold5 = [8000, 9000, 9400, 9700, 10000, 10250, 10500, 11000, 11250, 11500, 12000, 12500, 13000, 13250, 13500, 13750, 14000, 15000]
FPR5 = np.array([1, 0.94, 0.88, 0.82, 0.66, 0.55, 0.45, 0.22, 0.14, 0.09, 0.01, 0, 0, 0, 0, 0, 0, 0])
TPR5 = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.98, 0.88, 0.71, 0.56, 0.51, 0.35, 0.24, 0])
FNR5 = np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.02, 0.12, 0.29, 0.44, 0.49, 0.65, 0.76, 1])
TNR5 = np.array([0, 0.06, 0.12, 0.18, 0.34, 0.45, 0.55, 0.78, 0.86, 0.91, 0.99, 1, 1, 1, 1, 1, 1, 1])


##1Day detected over threshold
Threshold1 = [8000, 9000, 9400, 9700, 10000, 10250, 10500, 11000, 11250, 11500, 12000, 12500, 13000, 13250, 13500, 13750, 14000, 15000]
FPR1 = np.array([1, 0.91, 0.87, 0.77, 0.62, 0.55, 0.43, 0.26, 0.017, 0.1, 0.04, 0.02, 0, 0, 0, 0, 0, 0])
TPR1 = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.98, 0.92, 0.73, 0.67, 0.53, 0.33, 0.23, 0])
FNR1 = np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.02, 0.08, 0.27, 0.33, 0.47, 0.67, 0.77, 1])
TNR1 = np.array([0, 0.09, 0.13, 0.23, 0.38, 0.45, 0.57, 0.74, 0.83, 0.9, 0.96, 0.98, 1, 1, 1, 1, 1, 1])




    
# Find the mean area under the ROC curve              
area1 = auc(FPR1, TPR1)
area2 = auc(FPR2, TPR2)
area3 = auc(FPR3, TPR3)
area4 = auc(FPR4, TPR4)
area5 = auc(FPR3, TPR5)

area = (area1 +area2 + area3 + area4+area5)/5
print('AUC:', area)                     


SMALL_SIZE = 10
MEDIUM_SIZE = 15
BIGGER_SIZE = 15


# Plot FPR vs. TPR based on the mean values of 5 trials
FPR=(FPR1+FPR2+FPR3+FPR4+FPR5)/5
TPR=(TPR1+TPR2+TPR3+TPR4+TPR5)/5


fig, ax = plt.subplots()
ax.plot(FPR,TPR,'o',markersize=10,markerfacecolor='white',
         markeredgecolor='black',
         markeredgewidth=3)
ax.plot(FPR,TPR, 'red',linewidth=5)


leg = ax.legend(bbox_to_anchor=(0.3, 0.7), loc='upper left',framealpha=0.0,fontsize=BIGGER_SIZE);
#ax.set_xticks(np.arange(0, len(Threshold)+1, 100))
#plt.xticks(np.arange(1250, 1750, 50))
ax.tick_params(axis='x')
#ax.set_yscale('log')
#ax.set_xscale('log')
ax.set_xlabel("False Positive Rate",fontsize=BIGGER_SIZE,fontweight = 'bold')
ax.set_ylabel("True Positive Rate ",fontsize=BIGGER_SIZE,fontweight = 'bold')
#plt.xlim(0, 100)

plt.rc('font', size=MEDIUM_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=BIGGER_SIZE)
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"

#lt.yticks(np.arange(0, max(y), 2))

right_side = ax. spines["right"]
top_side = ax. spines["top"]
right_side. set_visible(False) 

top_side. set_visible(False) 
for axis in ['bottom','left']:
    ax.spines[axis].set_linewidth(3)
    
    
plt.savefig('ResultPlot/ROC_Curve29Days.pdf', bbox_inches='tight')